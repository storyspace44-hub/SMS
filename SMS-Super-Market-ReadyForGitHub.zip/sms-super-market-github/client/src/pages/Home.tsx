import { useEffect, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Clock3,
  Leaf,
  MapPin,
  Navigation,
  ShoppingBasket,
  Sparkles,
  Star,
  Store,
  Truck,
} from "lucide-react";

const mapUrl =
  "https://www.google.com/maps/search/?api=1&query=SMS+Super+Market%2C+1%2F865%2C+Madurai+-+Rameswaram+Hwy%2C+Pattinamkathan%2C+Tamil+Nadu+623504";

type Language = "en" | "ta";

const copy = {
  en: {
    notice: "A friendly stop for your everyday essentials",
    navAisles: "Our aisles",
    navVisit: "Visit us",
    heroEyebrow: "YOUR NEIGHBOURHOOD MARKET · PATTINAMKATHAN",
    heroTitleA: "Good things",
    heroTitleB: "for every day.",
    heroText:
      "Your neighbourhood stop for the little things that make home feel like home. Drop by SMS Super Market on the Madurai–Rameswaram Highway.",
    directions: "Get directions",
    browse: "Explore the aisles",
    rating: "Google rating",
    reviews: "26 local reviews",
    photoLabel: "Right here in your neighbourhood",
    photoCaption: "Find us on the Madurai–Rameswaram Highway",
    infoNearby: "A familiar local stop",
    infoDelivery: "Delivery listed",
    infoOpen: "Open · closes 8:45 pm",
    sectionEyebrow: "A LITTLE BIT OF EVERYTHING",
    sectionTitle: "Everyday essentials, all in one stop.",
    sectionText:
      "Take a look around the kinds of everyday staples you can find at a neighbourhood market. Ask in store for current selection and availability.",
    categoryNames: ["Fresh picks", "Pantry staples", "Dairy & more", "Snacks & treats", "Home care", "Daily needs"],
    categoryNotes: ["Fruit, vegetables & greens", "Rice, pulses & cooking basics", "Milk, ghee & chilled favourites", "Something for tea-time", "Useful things for home", "The little things on your list"],
    noteLabel: "A LOCAL SHOP, WITH A WARM WELCOME",
    noteTitle: "Your everyday stop, close to home.",
    noteText:
      "From pantry basics to household needs, SMS Super Market is a handy local stop in Pattinamkathan. Pop in, find what you need, and say hello.",
    visitTitle: "Come by today.",
    visitText: "We’re on the Madurai–Rameswaram Highway in Om Sakthi Nagar, Pattinamkathan.",
    addressLabel: "Find the store",
    hoursLabel: "Hours shown on listing",
    hoursValue: "Open · closes 8:45 pm",
    listingRating: "Rated by the neighbourhood",
    ratingReviews: "3.7 from 26 Google reviews",
    mapCta: "Open in Google Maps",
    deliveryTitle: "Prefer delivery?",
    deliveryText: "Delivery is listed for this store. Check with the shop for availability and ordering details.",
    deliveryCta: "View store location",
    footerLine: "Your neighbourhood stop for everyday needs.",
    footNote: "Store information from the details shared by the owner.",
    mapEyebrow: "A MAP TO THE NEIGHBOURHOOD",
    mapTitle: "A familiar landmark, easy to find.",
    mapText: "The map pin marks SMS Super Market near Avvai Street. Look for the Madurai–Rameswaram Highway and nearby local roads.",
    mapLandmarks: ["Avvai Street", "Sethu Ibrahim Street", "Pamboorani Road"],
    mapImageAlt: "Map screenshot showing the SMS Super Market pin near Avvai Street in Ramanathapuram",
    mapButton: "Open directions",
  },
  ta: {
    notice: "அன்றாடத் தேவைகளுக்கான உங்கள் அருகிலுள்ள கடை",
    navAisles: "கடையில்",
    navVisit: "வருகை",
    heroEyebrow: "உங்கள் அருகிலுள்ள கடை · பட்டினம்காத்தான்",
    heroTitleA: "அன்றாடத்",
    heroTitleB: "தேவைகள் அருகிலே.",
    heroText:
      "மதுரை–ராமேஸ்வரம் நெடுஞ்சாலையில் உள்ள எஸ்.எம்.எஸ் சூப்பர் மார்க்கெட் — உங்கள் அன்றாடத் தேவைகளுக்கான அருகிலுள்ள கடை.",
    directions: "வழியைப் பார்க்க",
    browse: "கடையைப் பாருங்கள்",
    rating: "Google மதிப்பீடு",
    reviews: "26 உள்ளூர் மதிப்புரைகள்",
    photoLabel: "உங்கள் அருகிலேயே",
    photoCaption: "மதுரை–ராமேஸ்வரம் நெடுஞ்சாலையில் எங்களைக் காணலாம்",
    infoNearby: "உங்கள் ஊரின் கடை",
    infoDelivery: "டெலிவரி பட்டியலிடப்பட்டுள்ளது",
    infoOpen: "திறந்துள்ளது · இரவு 8:45 வரை",
    sectionEyebrow: "அன்றாடத் தேவைகள் அனைத்தும்",
    sectionTitle: "உங்கள் அன்றாடப் பொருட்கள் ஒரே இடத்தில்.",
    sectionText:
      "அருகிலுள்ள கடையில் கிடைக்கக்கூடிய அன்றாடப் பொருட்களின் வகைகளைப் பாருங்கள். தற்போதைய பொருட்கள் மற்றும் இருப்பு குறித்து கடையில் விசாரிக்கவும்.",
    categoryNames: ["பழங்கள் & காய்கறிகள்", "மளிகைப் பொருட்கள்", "பால் & பிறவை", "தின்பண்டங்கள்", "வீட்டுப் பராமரிப்பு", "அன்றாடத் தேவைகள்"],
    categoryNotes: ["பழங்கள், காய்கறிகள், கீரைகள்", "அரிசி, பருப்பு, சமையல் பொருட்கள்", "பால், நெய் மற்றும் குளிர்பானங்கள்", "தேநீர் நேர சிற்றுண்டிகள்", "வீட்டிற்குத் தேவையானவை", "உங்கள் பட்டியலில் உள்ளவை"],
    noteLabel: "அன்பான வரவேற்புடன் உங்கள் உள்ளூர் கடை",
    noteTitle: "வீட்டிற்கு அருகிலுள்ள அன்றாடக் கடை.",
    noteText:
      "மளிகைப் பொருட்கள் முதல் வீட்டுத் தேவைகள் வரை, பட்டினம்காத்தானில் உள்ள எஸ்.எம்.எஸ் சூப்பர் மார்க்கெட் உங்கள் அருகிலுள்ள வசதியான கடை. வாருங்கள், தேவையானவற்றைப் பெற்றுச் செல்லுங்கள்.",
    visitTitle: "இன்றே வாருங்கள்.",
    visitText: "பட்டினம்காத்தான், ஓம் சக்தி நகர், மதுரை–ராமேஸ்வரம் நெடுஞ்சாலையில் உள்ளோம்.",
    addressLabel: "கடையைக் கண்டறிய",
    hoursLabel: "பட்டியலில் காட்டப்பட்ட நேரம்",
    hoursValue: "திறந்துள்ளது · இரவு 8:45 வரை",
    listingRating: "உள்ளூர் வாடிக்கையாளர்களின் மதிப்பீடு",
    ratingReviews: "26 Google மதிப்புரைகளில் 3.7",
    mapCta: "Google Maps-இல் திறக்கவும்",
    deliveryTitle: "டெலிவரி வேண்டுமா?",
    deliveryText: "இந்தக் கடைக்கு டெலிவரி வசதி பட்டியலிடப்பட்டுள்ளது. கிடைக்கும் விவரம் மற்றும் ஆர்டர் செய்ய கடையில் விசாரிக்கவும்.",
    deliveryCta: "கடை இருப்பிடத்தைப் பார்க்க",
    footerLine: "அன்றாடத் தேவைகளுக்கான உங்கள் அருகிலுள்ள கடை.",
    footNote: "உரிமையாளர் பகிர்ந்த தகவல்களின் அடிப்படையில்.",
    mapEyebrow: "அருகிலுள்ள இடங்களின் வரைபடம்",
    mapTitle: "எளிதில் கண்டுபிடிக்கக்கூடிய இடம்.",
    mapText: "அவ்வை தெருவுக்கு அருகில் எஸ்.எம்.எஸ் சூப்பர் மார்க்கெட் குறிக்கப்பட்டுள்ளது. மதுரை–ராமேஸ்வரம் நெடுஞ்சாலை மற்றும் அருகிலுள்ள தெருக்களை கவனியுங்கள்.",
    mapLandmarks: ["அவ்வை தெரு", "சேது இப்ராஹிம் தெரு", "பம்பூரணி சாலை"],
    mapImageAlt: "ராமநாதபுரத்தில் அவ்வை தெருவுக்கு அருகில் SMS சூப்பர் மார்க்கெட் குறிக்கப்பட்டுள்ள வரைபடம்",
    mapButton: "வழியைப் பார்க்க",
  },
} as const;

const categoryDetails = [
  { icon: "🍋", tint: "lime", doodle: "sun" },
  { icon: "🌾", tint: "wheat", doodle: "grain" },
  { icon: "🥛", tint: "sky", doodle: "drop" },
  { icon: "🍪", tint: "peach", doodle: "spark" },
  { icon: "🧹", tint: "rose", doodle: "home" },
  { icon: "🧺", tint: "sage", doodle: "basket" },
];

export default function Home() {
  const [language, setLanguage] = useState<Language>("en");
  const [showLoader, setShowLoader] = useState(true);
  const t = copy[language];

  useEffect(() => {
    const timer = window.setTimeout(() => setShowLoader(false), 1150);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const revealItems = Array.from(document.querySelectorAll<HTMLElement>(".reveal-item"));
    if (!("IntersectionObserver" in window)) {
      revealItems.forEach((item) => item.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: "0px 0px -5% 0px" });
    revealItems.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  const handleBackgroundPointer = (event: ReactPointerEvent<HTMLElement>) => {
    if (event.pointerType !== "mouse") return;
    event.currentTarget.style.setProperty("--pointer-x", `${event.clientX}px`);
    event.currentTarget.style.setProperty("--pointer-y", `${event.clientY}px`);
  };

  const handleTilt = (event: ReactPointerEvent<HTMLElement>) => {
    if (event.pointerType !== "mouse") return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width;
    const y = (event.clientY - bounds.top) / bounds.height;
    event.currentTarget.style.setProperty("--tilt-x", `${(0.5 - y) * 14}deg`);
    event.currentTarget.style.setProperty("--tilt-y", `${(x - 0.5) * 18}deg`);
    event.currentTarget.style.setProperty("--card-x", `${x * 100}%`);
    event.currentTarget.style.setProperty("--card-y", `${y * 100}%`);
  };

  const resetTilt = (event: ReactPointerEvent<HTMLElement>) => {
    event.currentTarget.style.setProperty("--tilt-x", "0deg");
    event.currentTarget.style.setProperty("--tilt-y", "0deg");
  };

  return (
    <main className={`site-shell${showLoader ? "" : " is-ready"}`} lang={language === "ta" ? "ta" : "en"} onPointerMove={handleBackgroundPointer} aria-busy={showLoader}>
      {showLoader && <div className="page-loader" role="status" aria-label="Loading SMS Super Market"><span className="loader-mark"><ShoppingBasket size={25} /></span><span className="loader-wordmark">SMS<small>SUPER MARKET</small></span></div>}
      <div className="topline">
        <div className="topline-inner">
          <span className="topline-dot" />
          <span>{t.notice}</span>
          <span className="topline-location">Pattinamkathan, Tamil Nadu</span>
        </div>
      </div>

      <header className="site-header">
        <a className="brand" href="#top" aria-label="SMS Super Market home">
          <span className="brand-mark"><ShoppingBasket size={22} strokeWidth={1.8} /></span>
          <span className="brand-name"><strong>SMS</strong><small>SUPER MARKET</small></span>
        </a>
        <nav className="main-nav" aria-label="Main navigation">
          <a href="#aisles">{t.navAisles}</a>
          <a href="#visit">{t.navVisit}</a>
        </nav>
        <div className="header-actions">
          <button
            className="language-toggle"
            onClick={() => setLanguage(language === "en" ? "ta" : "en")}
            aria-label={language === "en" ? "Switch to Tamil" : "Switch to English"}
          >
            <span className={language === "en" ? "active" : ""}>EN</span>
            <span className="toggle-divider">/</span>
            <span className={language === "ta" ? "active" : ""}>தமிழ்</span>
          </button>
          <a className="header-map" href={mapUrl} target="_blank" rel="noreferrer">
            {t.directions}<ArrowUpRight size={15} />
          </a>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy reveal-item">
          <div className="eyebrow"><span className="eyebrow-line" />{t.heroEyebrow}</div>
          <h1>{t.heroTitleA}<br /><em>{t.heroTitleB}</em></h1>
          <p className="hero-description">{t.heroText}</p>
          <div className="hero-buttons">
            <a className="button button-primary" href={mapUrl} target="_blank" rel="noreferrer">
              <Navigation size={17} />{t.directions}<ArrowUpRight size={16} />
            </a>
            <a className="button button-quiet" href="#aisles">{t.browse}<ArrowDownRight size={16} /></a>
          </div>
          <div className="hero-rating">
            <span className="rating-star"><Star size={16} fill="currentColor" strokeWidth={1.2} /></span>
            <span className="rating-score">3.7</span>
            <span className="rating-caption"><strong>{t.rating}</strong><small>{t.reviews}</small></span>
            <span className="rating-divider" />
            <span className="rating-google">G</span>
          </div>
        </div>

        <div className="hero-visual-wrap reveal-item">
          <div className="hero-photo-frame tilt-card" onPointerMove={handleTilt} onPointerLeave={resetTilt}>
            <img
              className="hero-photo"
              src="/images/sms-storefront.jpg"
              alt="SMS Super Market storefront in Pattinamkathan"
            />
            <div className="photo-caption"><span className="caption-pin"><MapPin size={15} /></span><span>{t.photoCaption}</span></div>
          </div>
          <div className="hero-photo-tag"><span className="tag-spark"><Sparkles size={15} /></span>{t.photoLabel}</div>
          <div className="hero-stamp" aria-hidden="true"><span>NEAR<br />& DEAR</span><Leaf size={16} /></div>
          <div className="hero-backdrop-shape" />
        </div>
      </section>

      <section className="quick-facts" aria-label="Store highlights">
        <div className="fact-item"><span className="fact-icon"><Store size={19} /></span><span>{t.infoNearby}</span></div>
        <span className="fact-separator" />
        <div className="fact-item"><span className="fact-icon"><Truck size={20} /></span><span>{t.infoDelivery}</span></div>
        <span className="fact-separator" />
        <div className="fact-item"><span className="fact-icon"><Clock3 size={19} /></span><span>{t.infoOpen}</span></div>
      </section>

      <section className="aisles-section" id="aisles">
        <div className="section-heading">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" />{t.sectionEyebrow}</div>
            <h2>{t.sectionTitle}</h2>
          </div>
          <p>{t.sectionText}</p>
        </div>
        <div className="category-grid">
          {t.categoryNames.map((name, index) => (
            <article className={`category-card tint-${categoryDetails[index].tint} reveal-item`} key={name}>
              <div className="category-card-top">
                <span className="category-number">0{index + 1}</span>
                <ArrowUpRight size={17} className="category-arrow" />
              </div>
              <span className={`category-illustration doodle-${categoryDetails[index].doodle}`} aria-hidden="true">{categoryDetails[index].icon}</span>
              <h3>{name}</h3>
              <p>{t.categoryNotes[index]}</p>
            </article>
          ))}
        </div>
        <p className="category-disclaimer"><span />Category examples are illustrative; availability may vary. <span className="tamil-disclaimer">கிடைக்கும் பொருட்கள் மாறுபடலாம்.</span></p>
      </section>

      <section className="neighborhood-section">
        <div className="neighborhood-photo tilt-card reveal-item" onPointerMove={handleTilt} onPointerLeave={resetTilt}>
          <img src="/images/sms-storefront.jpg" alt="The SMS Super Market sign and entrance" loading="lazy" />
          <span className="photo-corner-label">SMS · Pattinamkathan</span>
        </div>
        <div className="neighborhood-copy">
          <div className="eyebrow"><span className="eyebrow-line" />{t.noteLabel}</div>
          <h2>{t.noteTitle}</h2>
          <p>{t.noteText}</p>
          <a className="text-link" href={mapUrl} target="_blank" rel="noreferrer">{t.directions}<ArrowRight size={17} /></a>
          <div className="neighborhood-mark"><span className="mark-leaf"><Leaf size={18} /></span><span>சிறிய கடை · பெரிய அன்பு</span></div>
        </div>
      </section>

      <section className="visit-section reveal-item" id="visit">
        <div className="visit-main">
          <div className="eyebrow eyebrow-light"><span className="eyebrow-line" />PATTINAMKATHAN · TAMIL NADU</div>
          <h2>{t.visitTitle}</h2>
          <p>{t.visitText}</p>
          <a className="button button-light" href={mapUrl} target="_blank" rel="noreferrer">{t.mapCta}<ArrowUpRight size={16} /></a>
        </div>
        <div className="visit-details">
          <div className="detail-block">
            <span className="detail-icon"><MapPin size={19} /></span>
            <div><small>{t.addressLabel}</small><p>1/865, Madurai – Rameswaram Hwy,<br />Om Sakthi Nagar, Bharathi Nagar,<br />Pattinamkathan, Tamil Nadu 623504</p><span className="plus-code">9R6X+V8 Pattinamkathan</span></div>
          </div>
          <div className="detail-block">
            <span className="detail-icon"><Clock3 size={19} /></span>
            <div><small>{t.hoursLabel}</small><p>{t.hoursValue}</p><span className="small-note">Hours may change on holidays.</span></div>
          </div>
          <div className="detail-block">
            <span className="detail-icon"><Star size={18} /></span>
            <div><small>{t.listingRating}</small><p>{t.ratingReviews}</p></div>
          </div>
        </div>
      </section>

      <section className="map-reference-section" aria-labelledby="map-reference-title">
        <div className="map-reference-visual tilt-card reveal-item" onPointerMove={handleTilt} onPointerLeave={resetTilt}>
          <img src="/images/sms-location-map.jpg" alt={t.mapImageAlt} loading="lazy" />
          <span className="map-reference-pin"><MapPin size={15} fill="currentColor" /> SMS Super Market</span>
        </div>
        <div className="map-reference-copy">
          <div className="eyebrow"><span className="eyebrow-line" />{t.mapEyebrow}</div>
          <h2 id="map-reference-title">{t.mapTitle}</h2>
          <p>{t.mapText}</p>
          <div className="landmark-list">
            {t.mapLandmarks.map((landmark) => <span key={landmark}><MapPin size={13} />{landmark}</span>)}
          </div>
          <a className="text-link" href={mapUrl} target="_blank" rel="noreferrer">{t.mapButton}<ArrowUpRight size={16} /></a>
        </div>
      </section>

      <section className="delivery-strip">
        <div className="delivery-icon"><Truck size={23} /></div>
        <div className="delivery-copy"><h3>{t.deliveryTitle}</h3><p>{t.deliveryText}</p></div>
        <a href={mapUrl} target="_blank" rel="noreferrer" className="delivery-link">{t.deliveryCta}<ArrowUpRight size={15} /></a>
      </section>

      <footer className="site-footer">
        <a className="brand footer-brand" href="#top">
          <span className="brand-mark"><ShoppingBasket size={20} strokeWidth={1.8} /></span>
          <span className="brand-name"><strong>SMS</strong><small>SUPER MARKET</small></span>
        </a>
        <p>{t.footerLine}</p>
        <a className="footer-location" href={mapUrl} target="_blank" rel="noreferrer"><MapPin size={14} /> Pattinamkathan, Tamil Nadu</a>
        <small className="footer-note">{t.footNote}</small>
      </footer>

      <a className="mobile-directions" href={mapUrl} target="_blank" rel="noreferrer"><Navigation size={17} />{t.directions}<ArrowUpRight size={16} /></a>
    </main>
  );
}
